// ============================
// grass.h - written by BUzer
// ============================

void GrassInit();
void GrassVidInit();
void GrassDraw();
void GrassCreateEntities();