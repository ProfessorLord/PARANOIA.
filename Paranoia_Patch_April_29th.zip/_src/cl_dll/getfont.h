// ============================
// getfont - function, returning font pointer from text message
// written by BUzer
// ============================

#ifndef _GETFONT_H
#define _GETFONT_H

Font* FontFromMessage(const char* &ptext);

#endif // _GETFONT_H