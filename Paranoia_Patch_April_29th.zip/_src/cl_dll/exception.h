//
// exception filer header - written by BUzer for HL: Paranoia modification
//
//		2006


void InstallExceptionHandler();
void UnInstallExceptionHandler();


void LoadCrashRpt();
void UnloadCrashRpt();