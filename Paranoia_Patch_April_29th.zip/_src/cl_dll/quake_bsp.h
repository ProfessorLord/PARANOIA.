

int R_LightPoint (vec3_t &p, vec3_t &outcolor);